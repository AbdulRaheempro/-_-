A sleek, responsive personal website designed to showcase my skills and projects as a Front-End Developer. The website features:

Interactive Tab Navigation: Smooth transitions between sections like Skills, Experience, and Education.
Responsive Layout: Adapts to different screen sizes, providing an optimal viewing experience on any device.
Dynamic Content Loading: On-demand content updates for a richer user experience.
Dark Mode Toggle: Switch between light and dark themes for personalized viewing.
Technologies Used:

HTML
CSS
JavaScript
Key Features:

Tab Navigation: JavaScript-driven tabs for seamless content switching.
Enhanced Form Validation: Includes basic client-side validation for a better user experience.
Dark Mode: Option to switch between light and dark themes for better accessibility and user comfort.
Feel free to clone, contribute, or use it as a reference for your own projects!
