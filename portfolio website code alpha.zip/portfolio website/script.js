// Tab Navigation
const tabLinks = document.getElementsByClassName("tab-links");
const tabContents = document.getElementsByClassName("tab-content");

function openTab(tabName) {
    
  for (let link of tabLinks) {
        link.classList.remove("active-link");
    }

    
    for (let content of tabContents) {
        content.classList.remove("active-tab");
    }
    document.querySelector(`.tab-links[onclick="openTab('${tabName}')"]`).classList.add("active-link");
    document.getElementById(tabName).classList.add("active-tab");
}


document.addEventListener('DOMContentLoaded', function() {
  // Enhanced Form Validation
  const form = document.querySelector('form');
  form.addEventListener('submit', function(e) {
      const name = form.querySelector('input[name="Name"]').value.trim();
      const email = form.querySelector('input[name="email"]').value.trim();
      
      let valid = true;
      let errorMessage = '';

      if (name === '') {
          valid = false;
          errorMessage += 'Name field cannot be empty.\n';
      }

      if (email === '') {
          valid = false;
          errorMessage += 'Email field cannot be empty.\n';
      } else if (!validateEmail(email)) {
          valid = false;
          errorMessage += 'Please enter a valid email address.\n';
      }

      if (!valid) {
          alert(errorMessage);
          e.preventDefault();
      }
  });

  function validateEmail(email) {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return emailPattern.test(email);
  }
});




document.addEventListener('DOMContentLoaded', function() {
  // Dynamic Content Loading for Tabs
  const tabLinks = document.getElementsByClassName("tab-links");
  const tabContents = document.getElementsByClassName("tab-content");

  function openTab(tabName) {
      for (let link of tabLinks) {
          link.classList.remove("active-link");
      }

      for (let content of tabContents) {
          content.classList.remove("active-tab");
      }
      
      const activeLink = document.querySelector(`.tab-links[onclick="openTab('${tabName}')"]`);
      const activeContent = document.getElementById(tabName);
      
      activeLink.classList.add("active-link");
      activeContent.classList.add("active-tab");
      
      if (tabName === 'experience' && !activeContent.classList.contains('loaded')) {
          loadExperienceContent();
          activeContent.classList.add('loaded');
      }
  }

  function loadExperienceContent() {
      const contentDiv = document.getElementById('experience');
      contentDiv.innerHTML += `
          <ul>
              <li>Experience as a software engineer at XYZ Corp.</li>
              <li>Worked on a variety of high-impact projects.</li>
          </ul>
      `;
  }

  // Initialize the first tab
  openTab('skills');
});




document.addEventListener('DOMContentLoaded', function() {
  // Dark Mode Toggle
  const darkModeToggle = document.createElement('button');
  darkModeToggle.innerText = '🌙 Toggle Dark Mode';
  darkModeToggle.classList.add('dark-mode-toggle');
  document.body.appendChild(darkModeToggle);

  darkModeToggle.addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
      const isDarkMode = document.body.classList.contains('dark-mode');
      darkModeToggle.innerText = isDarkMode ? '🌞 Toggle Light Mode' : '🌙 Toggle Dark Mode';
  });
});


 